<?php
$serverName = 'balics-home.hu:2323';
$userName = 'timetable';
$password = 'Timetable@123';
$dbName = 'timetable';

$connect = mysqli_connect($serverName, $userName, $password, $dbName);